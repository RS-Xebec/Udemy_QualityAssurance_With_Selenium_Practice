# Take Input from User - Age, Add 5 to the age and print it

age = input("Please enter your age: - ") # "25"
age = int(age)+ 5   # String to Integer
print(age)


# Take integer to String
print("Your age is  "+ str(age))
