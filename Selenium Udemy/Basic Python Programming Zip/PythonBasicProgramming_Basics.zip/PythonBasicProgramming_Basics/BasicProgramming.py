# This is my Python File
# Indentation
print("Hello.... This is my first Python Code")
print("This is End of py Python Program")


# Take input from User
data = input("Please enter your name : -")
print(data)


# Variable
# Variables are used to hold data, value of variable can be change
a = 100
b = "Testing World"
a = 500
print(a)
print(b)


#  Define 2 variable
first_name = "Tom"
last_name  = "Jerry"
print(first_name + " " + last_name)