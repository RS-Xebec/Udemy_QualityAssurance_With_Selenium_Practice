# Variable
# Variables are used to hold data, value of variable can be change

user_age = 100
company_name = "Testing World"
email_id = "testingworldindia@gmail.com"

# My company name is Testing World and my email id is testingworldindia@gmail.com

print("My company name is " + company_name + " and my email id is "+email_id)

# Define multiple variables in a line
a,b,c = 10,"Hello",20
print(a)
print(b)
print(c)

# Assign same value to multiple variable
x = y = z = "Testing"
print(x)
print(y)
print(z)

#  Defining Constant here
SCHOOL_CODE =21335
print(SCHOOL_CODE)
SCHOOL_CODE = 21338
print(SCHOOL_CODE)


