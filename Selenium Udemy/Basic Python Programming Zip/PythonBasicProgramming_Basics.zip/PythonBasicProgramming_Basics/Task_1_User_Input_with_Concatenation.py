#Programming Question 1:
#Take Name, Age and Location from User
#Print data in following format
#User name is <NAME>, is <AGE> years old and lives in <LOCATION>

#Solution :
# Take Name from User
name= input("Please enter your name : -  ")

# Take Age from User
age= input("Please enter your age : -  ")

# Take Location from User
location = input("Please enter your Location : -  ")

print( "User name is " + name + ", is "+ age + " years old and lives in " + location)