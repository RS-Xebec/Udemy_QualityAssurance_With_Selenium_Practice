# Numeric Standard Type

score = 100  # Numeric Data Type
percentage = 77.23  # Numeric Data Type

# String Standard Type
user_message = "This is my user Message 777"
user_message.upper()

# List
li = [23,45,67.22, "Hello"]

# Tuple
tu = (23,45,67.22, "Hello")

# Dictionary
di = {"K1":"val1", "K2":"val2"}